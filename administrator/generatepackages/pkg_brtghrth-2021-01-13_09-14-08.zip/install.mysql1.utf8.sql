
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `paises` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `country_code` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `curtiu` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fb_order_country_code_INDEX` (`country_code`(10)),
  KEY `fb_order_country_INDEX` (`country`(10)),
  KEY `fb_order_latitude_INDEX` (`latitude`(10)),
  KEY `fb_order_longitude_INDEX` (`longitude`(10)),
  KEY `fb_order_curtiu_INDEX` (`curtiu`(10))
) ENGINE=MyISAM AUTO_INCREMENT=242 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cidades` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `estado` varchar(255) DEFAULT NULL,
  `cidade` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `capital` varchar(255) DEFAULT NULL,
  `nota` decimal(3,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fb_order_estado_INDEX` (`estado`(10)),
  KEY `fb_filter_estado_INDEX` (`estado`(10)),
  KEY `fb_order_cidade_INDEX` (`cidade`(10)),
  KEY `fb_order_capital_INDEX` (`capital`(10)),
  KEY `fb_order_longitude_INDEX` (`longitude`(10)),
  KEY `fb_order_latitude_INDEX` (`latitude`(10))
) ENGINE=MyISAM AUTO_INCREMENT=5565 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `livros` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `isbn` varchar(255) DEFAULT NULL,
  `book_title` varchar(255) DEFAULT NULL,
  `book_author` varchar(255) DEFAULT NULL,
  `year_of_publication` varchar(255) DEFAULT NULL,
  `publisher` varchar(255) DEFAULT NULL,
  `image_url_s` varchar(255) DEFAULT NULL,
  `image_url_m` varchar(255) DEFAULT NULL,
  `image_url_l` varchar(255) DEFAULT NULL,
  `pais` int(11) DEFAULT NULL,
  `local_da_publicacao` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fb_order_pais_INDEX` (`pais`),
  KEY `fb_filter_pais_INDEX` (`pais`),
  KEY `fb_order_isbn_INDEX` (`isbn`(10)),
  KEY `fb_order_book_title_INDEX` (`book_title`(10)),
  KEY `fb_filter_book_title_INDEX` (`book_title`(10)),
  KEY `fb_order_book_author_INDEX` (`book_author`(10)),
  KEY `fb_filter_book_author_INDEX` (`book_author`(10)),
  KEY `fb_order_year_of_publication_INDEX` (`year_of_publication`(10)),
  KEY `fb_order_publisher_INDEX` (`publisher`(10)),
  KEY `fb_order_local_da_publicacao_INDEX` (`local_da_publicacao`)
) ENGINE=MyISAM AUTO_INCREMENT=76982 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `documentos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_time` datetime DEFAULT NULL,
  `nome` varchar(255) DEFAULT NULL,
  `link` text DEFAULT NULL,
  `image` text DEFAULT NULL,
  `assunto` int(11) DEFAULT NULL,
  `status` text DEFAULT NULL,
  `estado` text DEFAULT NULL,
  `phplist` varchar(255) DEFAULT NULL,
  `tags` int(11) DEFAULT NULL,
  `texto_completo` text DEFAULT NULL,
  `arquivo` text DEFAULT NULL,
  `main_image` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fb_order_nome_INDEX` (`nome`(10)),
  KEY `fb_order_image_INDEX` (`image`(10)),
  KEY `fb_order_assunto_INDEX` (`assunto`),
  KEY `fb_order_date_time_INDEX` (`date_time`),
  KEY `fb_order_estado_INDEX` (`estado`(10)),
  KEY `fb_order_status_INDEX` (`status`(10)),
  KEY `fb_order_phplist_INDEX` (`phplist`(10)),
  KEY `fb_order_tags_INDEX` (`tags`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assuntos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_time` datetime DEFAULT NULL,
  `nome` varchar(255) DEFAULT NULL,
  `prazo_corrente` int(11) DEFAULT NULL,
  `prazo_intermediario` int(11) DEFAULT NULL,
  `destinacao` text DEFAULT NULL,
  `imagem` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fb_order_nome_INDEX` (`nome`(10)),
  KEY `fb_order_prazo_corrente_INDEX` (`prazo_corrente`),
  KEY `fb_order_prazo_intermediario_INDEX` (`prazo_intermediario`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usu_rios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_time` datetime DEFAULT NULL,
  `nome` varchar(255) DEFAULT NULL,
  `cpf` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fb_order_nome_INDEX` (`nome`(10)),
  KEY `fb_order_cpf_INDEX` (`cpf`(10))
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chamados` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_time` datetime DEFAULT NULL,
  `titulo` varchar(255) DEFAULT NULL,
  `status` text DEFAULT NULL,
  `cliente` int(11) DEFAULT NULL,
  `descricao` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fb_order_titulo_INDEX` (`titulo`(10)),
  KEY `fb_order_date_time_INDEX` (`date_time`),
  KEY `fb_order_usuario_INDEX` (`cliente`),
  KEY `fb_order_status_INDEX` (`status`(10))
) ENGINE=MyISAM AUTO_INCREMENT=69 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tarefas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_time` datetime DEFAULT NULL,
  `titulo` varchar(255) DEFAULT NULL,
  `status` text DEFAULT NULL,
  `chamado` int(11) DEFAULT NULL,
  `atendente` int(11) DEFAULT NULL,
  `observacao` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fb_order_titulo_INDEX` (`titulo`(10)),
  KEY `fb_order_chamado_INDEX` (`chamado`),
  KEY `fb_order_date_time_INDEX` (`date_time`)
) ENGINE=MyISAM AUTO_INCREMENT=113 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bpms_etapas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_time` datetime DEFAULT NULL,
  `usuario19` int(11) DEFAULT NULL,
  `processo` int(11) DEFAULT NULL,
  `etapa_anterior` int(11) DEFAULT NULL,
  `titulo` varchar(255) DEFAULT NULL,
  `lista_origem` int(6) DEFAULT NULL,
  `acao_tu` text DEFAULT NULL,
  `lista_destino` int(6) DEFAULT NULL,
  `acao_ts` text DEFAULT NULL,
  `pk_fk` text DEFAULT NULL,
  `foreign_pk` int(6) DEFAULT NULL,
  `row` varchar(255) DEFAULT NULL,
  `where` text DEFAULT NULL,
  `condicao` text DEFAULT NULL,
  `tipo` text DEFAULT NULL,
  `bpmn_id` varchar(255) DEFAULT NULL,
  `plugins_form` text DEFAULT NULL,
  `bpmn_xml` text DEFAULT NULL,
  `etapas_anteriores` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fb_order_usuario19_INDEX` (`usuario19`),
  KEY `fb_order_processo_INDEX` (`processo`),
  KEY `fb_filter_processo_INDEX` (`processo`),
  KEY `fb_order_lista_destino_INDEX` (`lista_destino`),
  KEY `fb_order_acao_da_tarefa_INDEX` (`acao_ts`(10)),
  KEY `fb_order_date_time_INDEX` (`date_time`),
  KEY `fb_order_etapa_anterior_INDEX` (`etapa_anterior`),
  KEY `fb_order_titulo_da_atividade_INDEX` (`titulo`(10)),
  KEY `fb_order_formulario_origem_INDEX` (`lista_origem`),
  KEY `fb_order_acao_da_atividade_INDEX` (`acao_tu`(10)),
  KEY `fb_order_tipo_INDEX` (`tipo`(10))
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bpms_processos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_time` datetime DEFAULT NULL,
  `titulo` varchar(255) DEFAULT NULL,
  `descricao` text DEFAULT NULL,
  `usuario` int(11) DEFAULT NULL,
  `diagrama` text DEFAULT NULL,
  `xml_bpmn` text DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fb_order_titulo_INDEX` (`titulo`(10)),
  KEY `fb_order_usuario_INDEX` (`usuario`),
  KEY `fb_order_date_time_INDEX` (`date_time`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `livros_repeat_cidades` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT NULL,
  `cidades` int(11) DEFAULT NULL,
  `params` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fb_parent_fk_parent_id_INDEX` (`parent_id`),
  KEY `fb_repeat_el_cidades_INDEX` (`cidades`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `documentos_18_repeat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT NULL,
  `nome` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fb_parent_fk_parent_id_INDEX` (`parent_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `documentos_repeat_tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT NULL,
  `tags` int(11) DEFAULT NULL,
  `params` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fb_parent_fk_parent_id_INDEX` (`parent_id`),
  KEY `fb_repeat_el_tags_INDEX` (`tags`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bpms_etapas_59_repeat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT NULL,
  `operacao` text DEFAULT NULL,
  `elemento` int(6) DEFAULT NULL,
  `condicional` text DEFAULT NULL,
  `valor` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fb_parent_fk_parent_id_INDEX` (`parent_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bpms_etapas_60_repeat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT NULL,
  `elemento` int(6) DEFAULT NULL,
  `valor` text DEFAULT NULL,
  `default` varchar(255) DEFAULT NULL,
  `php` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fb_parent_fk_parent_id_INDEX` (`parent_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bpms_etapas_repeat_etapas_anteriores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT NULL,
  `etapas_anteriores` int(11) DEFAULT NULL,
  `params` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fb_parent_fk_parent_id_INDEX` (`parent_id`),
  KEY `fb_repeat_el_etapas_anteriores_INDEX` (`etapas_anteriores`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

